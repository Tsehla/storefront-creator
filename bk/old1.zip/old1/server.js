const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const path = require('path');

dotenv.config();

const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static('./public'));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// MongoDB Atlas connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/store_fronts', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => {
    console.log('Connected to MongoDB Atlas');
})
.catch((err) => {
    console.error('MongoDB connection error:', err);
});

// Store Schema
const storeSchema = new mongoose.Schema({
    storeName: String,
    description: String,
    ownerName: String,
    contactEmail: String,
    products: [{
        name: String,
        price: Number,
        description: String
    }]
});

const Store = mongoose.model('Store', storeSchema);

// Routes
app.get('/', (req, res) => {
    res.render('index');
});

app.get('/create-store', (req, res) => {
    res.render('create-store');
});

app.post('/create-store', async (req, res) => {
    try {
        const store = new Store(req.body);
        await store.save();
        res.redirect(`/store/${store._id}`);
    } catch (err) {
        res.status(400).send(err);
    }
});

app.get('/store/:id', async (req, res) => {
    try {
        const store = await Store.findById(req.params.id);
        if (!store) {
            return res.status(404).send('Store not found');
        }
        res.render('store', { store });
    } catch (err) {
        res.status(404).send('Store not found');
    }
});

// Server startup
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
